var usage = function () {
  return 'usage: bolt dev [-p|--project PROJECT_FILE] [-c|--config CONFIG_DIR]\n' +
         '                [CONFIG BOOTSTRAP] ...\n' +
         '\n' +
         'arguments:\n' +
         '  CONFIG                      a bolt configuration file to generate a dev\n' +
         '                              bootstrap script for. Multiple CONFIG files can be\n' +
         '                              specified, a dev bootstrap script will be\n' +
         '                              generated for each. Every CONFIG file must be\n' +
         '                              paired with a corresponding BOOTSTRAP argument.\n' +
         '  BOOTSTRAP                   file to save to the generated dev bootstrap script\n' +
         '                              to. The generated dev bootstrap script links to\n' +
         '                              its associated CONFIG file, so this command only\n' +
         '                              needs to be run once, changes to the CONFIG file\n' +
         '                              are automatically picked up.\n' +
         '\n' +
         'options:\n' +
         '  -p|--project PROJECT_FILE   override project configuration file. This json\n' +
         '                              configuration file format allows defaults to be\n' +
         '                              specified for all bolt command line arguments.\n' +
         '                                default: project.json\n' +
         '  -c|--config CONFIG_DIR      override bolt configuration directory. A dev\n' +
         '                              bootstrap script will be generated for all *.js\n' +
         '                              files in the directory. Ignored if any CONFIG and\n' +
         '                              BOOTSTRAP arguments are provided.\n' +
         '                                default: config/bolt\n' +
         '\n' +
         'example:\n' +
         '  Initialise a project after checkout.\n' +
         '\n' +
         '    bolt dev\n';
};

var fail_usage = function (code, message) {
  console.error(message);
  console.error('');
  console.error(usage());
  process.exit(code);
};

var fail = function (code, message) {
  console.error(message);
  process.exit(code);
};


module.exports = function (help_mode) {
  if (help_mode) {
    console.log(usage());
    process.exit();
  }

  var config_dir = 'config/bolt';

  while (process.argv.length > 0 && process.argv[0][0] === '-') {
    var flag = process.argv[0];
    process.argv.shift();

    switch (flag) {
      case '-c':
      case '--config':
        if (process.argv.length < 1)
          fail_usage(1, flag + ' requires an argument to be specified');
        config_dir = process.argv[0];
        process.argv.shift();
        break;
      case '--':
        break;
      default:
        fail_usage(1, 'invalid flag [' + flag +']');
    }
  }


  require('./../lib/base');
  require('./../lib/kernel');
  require('./../lib/loader');
  require('./../lib/module');
  require('./../lib/compiler');

  var fs = require('fs');

  if (!fs.existsSync(config_dir))
    fs.mkdirSync(config_dir);
  else if (!fs.statSync(config_dir).isDirectory())
    fail_usage(2, 'directory specified for CONFIG_DIR exists but is not a directory');

  var files = fs.readdirSync(config_dir).filter(function (file) {
    return fs.statSync(config_dir + '/' + file).isFile() &&
           file.indexOf('bootstrap') !== 0 &&
           file.length > 3 && file.lastIndexOf('.js') === file.length - 3;
  });

  files.forEach(function (file) {
    var config = config_dir + '/' + file;
    var bootstrap = config_dir + '/bootstrap-' + file;
    bolt.compiler.mode.Dev.run(config, bootstrap);
  });
};
