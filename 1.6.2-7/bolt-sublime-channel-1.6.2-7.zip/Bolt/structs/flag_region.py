class FlagRegion:

    def __init__(self, name, format, icon, mode):
        self.name = name
        self.format = format
        self.icon = icon
        self.mode = mode

