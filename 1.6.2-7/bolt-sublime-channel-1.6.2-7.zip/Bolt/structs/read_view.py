class ReadView:

    def __init__(self, base, filename, nests, module_name, spot, ptext, external):
        self.base = base
        self.filename = filename
        self.nests = nests
        self.module_name = module_name
        self.spot = spot
        self.ptext = ptext
        self.external = external

