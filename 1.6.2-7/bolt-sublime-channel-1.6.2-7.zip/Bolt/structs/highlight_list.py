class HighlightList:

    def __init__(self, incorrect, missing, unused):
        self.incorrect = incorrect
        self.missing = missing
        self.unused = unused

