

class PlasmaText:

    def __init__(self, deps, injs):
        self.deps = deps
        self.injs = injs
