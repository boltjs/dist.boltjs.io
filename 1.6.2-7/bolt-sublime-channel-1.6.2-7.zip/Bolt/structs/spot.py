class Spot:

    def __init__(self, token, begin, end):
        self.token = token
        self.begin = begin
        self.end = end
