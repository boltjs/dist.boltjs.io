class FindPattern:

    def __init__(self, dir, pattern, extract_dep):
        self.dir = dir
        self.pattern = pattern
        self.extract_dep = extract_dep

