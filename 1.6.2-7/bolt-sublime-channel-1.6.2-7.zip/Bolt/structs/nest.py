class Nest:

    def __init__(self, base, pattern, dep, path):
        self.base = base
        self.pattern = pattern
        self.dep = dep
        self.path = path

