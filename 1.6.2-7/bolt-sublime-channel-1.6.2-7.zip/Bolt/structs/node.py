class Node:

    def __init__(self, dir, package):
        self.dir = dir
        self.package = package

