

def file(view, path):
    view.window().open_file(path)
