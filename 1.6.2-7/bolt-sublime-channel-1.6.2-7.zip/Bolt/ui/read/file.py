

def filename(view):
    return view.file_name()
