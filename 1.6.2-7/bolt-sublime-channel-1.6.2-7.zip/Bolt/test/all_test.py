import unittest


from structs_test import *
from util_test import *
from templates_test import *


if __name__ == '__main__':
    unittest.main()
